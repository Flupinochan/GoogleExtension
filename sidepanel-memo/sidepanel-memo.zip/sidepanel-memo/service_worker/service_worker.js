(function(){"use strict";chrome.runtime.onInstalled.addListener(()=>{chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}),console.log("SidePanel設定完了")})})();
